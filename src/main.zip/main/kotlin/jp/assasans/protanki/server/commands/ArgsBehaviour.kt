package jp.assasans.protanki.server.commands

annotation class ArgsBehaviour(val type: ArgsBehaviourType)

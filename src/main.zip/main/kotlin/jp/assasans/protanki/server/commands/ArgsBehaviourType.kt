package jp.assasans.protanki.server.commands

enum class ArgsBehaviourType {
  Arguments,
  Raw
}

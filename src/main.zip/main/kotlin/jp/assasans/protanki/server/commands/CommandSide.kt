package jp.assasans.protanki.server.commands

enum class CommandSide {
  Server,
  Client
}

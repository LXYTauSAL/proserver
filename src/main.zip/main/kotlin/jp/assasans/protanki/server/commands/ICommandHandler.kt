package jp.assasans.protanki.server.commands

interface ICommandHandler {}

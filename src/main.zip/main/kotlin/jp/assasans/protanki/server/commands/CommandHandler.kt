package jp.assasans.protanki.server.commands

annotation class CommandHandler(val name: CommandName)
